﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using QRCoder;
using WebQrCode.Models;

namespace WebQrCode.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {

            QRCodeGenerator qrCodeGenerator = new QRCodeGenerator();

            var conteudo = new Conteudo
            {
                Id = 100,
                Nome = "Valdir Ferreira",
                CPF = "303022151447"
            };


            var json = JsonConvert.SerializeObject(conteudo);
            QRCodeData qrCodeData = qrCodeGenerator.CreateQrCode(json, QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrCodeData);
            Bitmap qrCodeImage = qrCode.GetGraphic(20);
            var bitmapBytes = BitmapToBytes(qrCodeImage);


            return File(bitmapBytes, "image/jpeg");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


        private static byte[] BitmapToBytes(Bitmap img)
        {
            using (MemoryStream stream = new MemoryStream())
            {
                img.Save(stream, System.Drawing.Imaging.ImageFormat.Png);

                return stream.ToArray();
            }
        }

    }
}
